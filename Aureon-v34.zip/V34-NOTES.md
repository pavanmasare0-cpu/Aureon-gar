# v34 — Ava Studio retry wait chhota + asli wajah dikhti hai
- Pehle: AI quota/limit par 30s, phir 60s, 120s ... 15 min tak ruk jati thi.
- Ab: 5s, 10s, 20s, 40s, max 60s (aur agar koi key/model jaldi wapas aa raha ho to utna hi). Env se badal sakte ho: AVA_STUDIO_WAIT_MS (default 5000), AVA_STUDIO_WAIT_MAX_MS (default 60000).
- Status line me ab asli wajah bhi dikhti hai ("wajah: gemini/... 429 ...").
- Ye sirf wait ka time kam karta hai. Agar saari keys ka quota khatam/zero hai to build tab bhi nahi chalegi.
