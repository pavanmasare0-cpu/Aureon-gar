# v33 — saari keys har jagah + AI video generation
- backend/keys.js (naya): GEMINI_API_KEY / _2 ... _99 / GEMINI_API_KEYS, aur GROQ ke liye wahi. Ek key fail to agli.
- server.js: envKeys ab _99 tak (chat, coding, Ava, form-fill sab callGemini/callGroq se). Photo generate/edit aur knowledge embeddings ab saari Gemini keys try karte hain.
- llm-text.js (Ava Studio / APK Studio / Apps & Automation): ab _99 tak.
- sentinel-dashboard.js, security/textscan.js: Groq keys rotate.
- backend/video-gen.js (naya) + www/video-ui.js (naya, 🎬 button): AI video (Veo). Saari Gemini keys + model fallback.
  Routes: POST /api/generate-video, GET /api/generate-video/:id, GET /api/generate-video/:id/file
  Veo aksar billing-enabled Gemini key maangta hai. Free key par 403/429 aa sakta hai.
- Video EDITING (trim/caption/convert) pehle jaisa: ffmpeg, koi key nahi lagti.
Deploy: backend => Render redeploy. www/ badla => APK rebuild.
