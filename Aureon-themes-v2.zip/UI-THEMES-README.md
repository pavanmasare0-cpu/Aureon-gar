# Aureon UI Themes update v2

Settings > Theme mein 6 options:
Nebula Aurora (default), Deep Ocean, Cyberpunk Neon, Emerald Intelligence,
White + Electric Purple (light), Classic Gold (purani).

## Files
- www/index.html   (theme row + picker, themes.css/theme.js links)
- www/themes.css   (NEW — saari themes)
- www/theme.js     (NEW — theme switcher, choice yaad rakhta hai)
- www/app.js       (1 line: Sentinel kholte waqt theme bhi bhejta hai)
- backend/sentinel-dashboard.js  (Sentinel ab same themes follow karta hai + dropdown)

## Lagane ke baad
- App: `npx cap sync android` -> build
- Sentinel: git push -> Render redeploy (APK rebuild ki zarurat nahi)
