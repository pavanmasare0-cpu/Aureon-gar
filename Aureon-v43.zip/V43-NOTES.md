# v43 — brain me sab kuch (v41 + v42 ke upar)
Ab neuron banta hai (sirf owner ke events; keys/tokens/passwords/JWT text se [hidden] ho jaate hain):
- Chat: har jawab ka ek neuron: sawal (80 akshar) + jawab ka shuruaati hissa (code ki jagah [code]). Coding/Code mode -> Tark, baaki -> Yaad.
- Reminders, "yaad rakha" facts, Memory notes ka update, Knowledge docs (naam + chunks).
- APK builds: start / queued / done / failed.
- Sentinel + Ava Guard events (down/up/deploy/proposal/approved/rejected) aur Ava ke upgrade proposals.
- Owner actions (dashboards ke sensitive actions).
- Keys: boot par aur har 6 ghante me (ginti + kaun si Gemini key aakhri chali). Test calls nahi hoti, quota nahi lagta.
- Purana sab kuch ek baar: skills, lessons, knowledge docs, memory notes, purani saved chats. Owner ki pehli chat par khud chalta hai; dobara chalana ho to POST /api/brain/backfill?force=1.
Deploy: sirf backend => Render redeploy.
