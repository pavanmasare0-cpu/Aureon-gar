package com.aureon.ai;

import android.content.Context;
import android.service.voice.VoiceInteractionSession;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

/**
 * This is what actually appears on screen — the floating overlay window,
 * shown on top of whatever the user was doing (lock screen, another app,
 * home screen). Equivalent to what you see when you say "Hey Google".
 *
 * onCreateContentView() is where the overlay's layout is inflated. Right now
 * it shows a placeholder — swap aureon_voice_overlay.xml for the real glow
 * orb / animated UI once the visual theme is built.
 */
public class AureonVoiceInteractionSession extends VoiceInteractionSession {

    public AureonVoiceInteractionSession(Context context) {
        super(context);
    }

    @Override
    public View onCreateContentView() {
        View view = LayoutInflater.from(getContext())
                .inflate(R.layout.aureon_voice_overlay, null);

        TextView statusText = view.findViewById(R.id.aureon_status_text);
        if (statusText != null) {
            statusText.setText("Listening…");
        }

        // TODO: start speech recognition here to capture what the user says
        // after the wake word, then send it to https://aureone.onrender.com/api/chat
        // and display/speak the reply inside this same overlay.

        return view;
    }
}
