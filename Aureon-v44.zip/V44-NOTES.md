# v44 (v41, v42, v43 ke upar)
1. Stop button: jab AI jawab likh raha ho ya auto test & fix chal raha ho, chat me "Stop" dikhta hai. Dabane par request ruk jati hai ("Roka gaya"), fix rounds bhi ruk jaate hain. (Server par jo kaam shuru ho chuka wo apne aap khatam hota hai.)
2. Coding mode me bhi installed skills ki relevant list (Code mode jaisi). Skill install chat se (link ya "npx skills add owner/repo") sab modes me pehle se chalta hai. Skills pane me "Coding mode chalu" button bhi.
3. Brain page (ava-brain.html):
   - Lobe ke button (Soch, Tark, Yaadein ...) dabao: sirf usi lobe ki yaadein dikhti hain, baaki chhup jaati hain (labels bhi). Dobara dabao/reset: sab wapas.
   - Umr ke hisaab se gehrai: pichle 24 ghante ki yaadein upar (core me); 1-7 din, 7-30 din, 30+ din ki yaadein kramshah gehri; gehri yaadein tabhi dikhti hain jab zoom/dive karo. Timestamp na ho to upar.
Deploy: backend (server.js, ava-brain.html) => Render redeploy. www/ => APK rebuild.
