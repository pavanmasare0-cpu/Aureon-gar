# Aureon UI Themes update

Settings > Theme mein 3 options:
- Nebula Aurora (default)
- Cyberpunk Neon
- Classic Gold (purani theme)

## Kaise lagana hai
1. Is zip ke www/ ke 3 files apne project ke www/ mein copy karo (replace):
   - index.html  (themes.css link, Theme row + pane, theme.js)
   - themes.css  (NEW)
   - theme.js    (NEW)
   style.css aur app.js mein koi change nahi hai.
2. Terminal: npx cap sync android, phir Android Studio / GitHub Actions se build.

## Technical notes
- Choice localStorage key "aureon_theme" mein save hoti hai (nebula | cyber | classic).
- <html data-theme="..."> set hota hai; Classic mein attribute hata diya jata hai, isliye purani gold UI bilkul waisi hi rehti hai.
- Splash screen, home star, composer, chat bubbles, Settings sab theme ke hisaab se badalte hain.
- Native voice orb (AureonNebulaLightningView, Java) is update mein change nahi hua.
