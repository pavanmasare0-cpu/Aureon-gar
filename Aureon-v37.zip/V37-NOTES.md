# v37 (cumulative: v33-v37 ek saath)
- Skills: GitHub link, raw.githubusercontent link, git@github.com:..., aur terminal-style commands se install:
    "npx skills add owner/repo", "git clone https://github.com/owner/repo", "gh repo clone owner/repo", "owner/repo skill install karo".
  (Command chalta nahi, sirf parse hota hai.) Doosri website ka link: saaf message milta hai ki GitHub chahiye.
  Skills ki ginti practically unlimited; ek message me jodi jaane wali skills: AUREON_SKILLS_PER_PROMPT (default 2).
- Language: Settings > General > "Reply language (Aureon + Ava)": Auto / Hinglish / English.
  Aureon chat system prompt me rule jud jata hai; Ava ke AI calls me header x-ava-lang se English rule lagta hai (Ava Desk ka apna 🌐 button bhi ab Ava ke jawab badalta hai).
- Pehle ke badlav: v33 (keys + video), v34 (Ava Studio retry), v35 (code review rounds), v36 (skills limit).
- www/ badla => APK rebuild; backend => Render redeploy.
