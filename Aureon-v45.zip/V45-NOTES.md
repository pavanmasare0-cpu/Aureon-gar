# v45 (v44 ke upar) — brain me kaun si cheez kahan jaati hai
Lobe rules (naye lobe nahi; 7 wahi):
- Soch (cyan): sab chats (Aureon ki har chat, purani saved chats), Ava ki baatcheet/thoughts, server boot, keys status, owner actions.
- Tark (blue): AUREON ne jo seekha — lessons, skills install, fix & re-run/review se mile sabak; tests pass.
- Yaadein (golden): SIRF asli yaadein — memory notes, "yaad rakha" facts, reminders, knowledge docs, Ava ke seekhe facts (user ke baare me).
- Dar (red): errors, fail runs/tests/builds/videos, watchdog, Sentinel down/bad deploy, jo Ava nahi kar paayi.
- Bhavna (pink): feedback/thanks/rejected.
- Drishti (green): AVA ne jo seekha — reflections, apne banaye niyam (playbook), skill checks, Ava Studio tests pass — aur jo Ava dekhti hai.
- Sapne (purple): jo banaya — APK, projects, photos, videos, upgrades approve.
Purane events: pehli baar load par har purana event naye lobe me chala jata hai aur totals ek baar dobara ginte jaate hain (schema 2).
Brain page: lobe dabao => sirf wahi lobe (base neurons 97% dim + deep zoom ka poora field us lobe ke rang me).
Deploy: backend => Render redeploy (APK rebuild nahi).
