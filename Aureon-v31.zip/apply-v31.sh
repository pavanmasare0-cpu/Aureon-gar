#!/bin/bash
# v31: purani Ava Guard + Claude connector files hatao
rm -f backend/claude-connector.js backend/public/ava-guard.js backend/test/ava-guard.test.js www/ava-guard.js www/claude-hub.js
rm -f -- "$0"
echo "v31 apply done"
