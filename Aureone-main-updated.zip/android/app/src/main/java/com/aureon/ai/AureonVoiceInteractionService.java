package com.aureon.ai;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.voice.VoiceInteractionSession;
import android.service.voice.VoiceInteractionService;
import android.util.Log;
import android.widget.Toast;

/**
 * System-level entry point. Android starts this once Aureon AI is set as the
 * phone's Default Digital Assistant (Settings > Apps > Default apps > Digital
 * assistant app).
 *
 * Runs the low-power WakeWordDetector (openWakeWord / ViolaWake ONNX models)
 * in the background instead of a full SpeechRecognizer loop — this is the
 * same approach "Hey Google" / "Alexa" use, so the mic doesn't have to run
 * full cloud/on-device speech-to-text all day. Only once "Aureon" is
 * detected does it launch the assistant overlay via showSession(), which is
 * where the existing AureonVoiceInteractionSession takes over and runs the
 * real SpeechRecognizer to capture the actual command.
 */
public class AureonVoiceInteractionService extends VoiceInteractionService
        implements WakeWordDetector.Listener {

    private static final String TAG = "AureonVoiceService";
    private static final long AFTER_TRIGGER_PAUSE_MS = 5000; // let the overlay have the mic first

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WakeWordDetector wakeWordDetector;
    private boolean running = false;

    @Override
    public void onReady() {
        super.onReady();
        Log.d(TAG, "Aureon voice interaction service ready.");
        running = true;

        wakeWordDetector = new WakeWordDetector(this, this);
        mainHandler.post(() -> {
            if (running) wakeWordDetector.start();
        });
    }

    @Override
    public void onShutdown() {
        super.onShutdown();
        Log.d(TAG, "Aureon voice interaction service shutting down.");
        running = false;
        if (wakeWordDetector != null) {
            wakeWordDetector.release();
        }
    }

    // ---------------- WakeWordDetector.Listener ----------------

    @Override
    public void onWakeWordDetected(float score) {
        // Called on the detector's background thread — hop to main for UI/session work.
        mainHandler.post(() -> {
            Log.d(TAG, "Wake word detected, score=" + score + " — launching overlay.");
            Toast.makeText(this, "Aureon activated", Toast.LENGTH_SHORT).show();

            if (wakeWordDetector != null) wakeWordDetector.stop();
            showSession(new Bundle(), VoiceInteractionSession.SHOW_WITH_ASSIST);

            // Give the overlay session a clear run at the mic, then resume wake-word listening.
            mainHandler.postDelayed(() -> {
                if (running && wakeWordDetector != null) wakeWordDetector.start();
            }, AFTER_TRIGGER_PAUSE_MS);
        });
    }

    @Override
    public void onError(String message) {
        Log.e(TAG, "WakeWordDetector error: " + message);
        mainHandler.post(() -> Toast.makeText(this, "Aureon mic error: " + message, Toast.LENGTH_LONG).show());
    }
}
