package com.aureon.ai;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import java.util.Random;

/**
 * The animated golden "energy orb" shown on Aureon's voice overlay — a
 * stylized approximation of the After Effects reference the user provided:
 * a rotating wireframe sphere, radiating light rays, orbiting sparkle
 * particles, a pulsing center glow, and a sweeping arc. Everything moves
 * continuously while the view is animating.
 *
 * This is drawn live with Canvas each frame rather than a pre-rendered
 * video/Lottie file, since no export of the original AE animation was
 * available — it's a simplified but full-motion equivalent in the same
 * gold/orange palette as the app's theme.
 */
public class AureonEnergyOrbView extends View {

    private static final int GOLD = Color.parseColor("#FFD54A");
    private static final int ORANGE = Color.parseColor("#FF8C1A");
    private static final int NUM_RAYS = 9;
    private static final int NUM_PARTICLES = 36;

    private float rotation = 0f; // 0-360, drives most of the motion
    private ValueAnimator animator;

    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wireframePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint corePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final float[] particleAngleOffset = new float[NUM_PARTICLES];
    private final float[] particleRadiusFrac = new float[NUM_PARTICLES];
    private final float[] particleSpeed = new float[NUM_PARTICLES];
    private final float[] particleSize = new float[NUM_PARTICLES];

    public AureonEnergyOrbView(Context context) {
        super(context);
        init();
    }

    public AureonEnergyOrbView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        wireframePaint.setStyle(Paint.Style.STROKE);
        wireframePaint.setStrokeWidth(2f);
        wireframePaint.setColor(ORANGE);
        wireframePaint.setAlpha(90);

        rayPaint.setStyle(Paint.Style.STROKE);
        rayPaint.setStrokeWidth(2.5f);
        rayPaint.setStrokeCap(Paint.Cap.ROUND);

        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeWidth(6f);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        arcPaint.setColor(GOLD);

        particlePaint.setStyle(Paint.Style.FILL);
        particlePaint.setColor(GOLD);

        corePaint.setStyle(Paint.Style.FILL);

        Random rnd = new Random(7); // fixed seed so layout is stable across recompositions
        for (int i = 0; i < NUM_PARTICLES; i++) {
            particleAngleOffset[i] = rnd.nextFloat() * 360f;
            particleRadiusFrac[i] = 0.55f + rnd.nextFloat() * 0.55f; // 0.55–1.1x orb radius
            particleSpeed[i] = 0.3f + rnd.nextFloat() * 1.2f;
            particleSize[i] = 1.5f + rnd.nextFloat() * 2.5f;
        }
    }

    public void startAnimating() {
        if (animator != null) return;
        animator = ValueAnimator.ofFloat(0f, 360f);
        animator.setDuration(6000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(anim -> {
            rotation = (float) anim.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    public void stopAnimating() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopAnimating();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float orbRadius = Math.min(getWidth(), getHeight()) / 2f * 0.85f;
        if (orbRadius <= 0) return;

        double t = rotation / 360.0; // 0..1 progress through the loop

        // 1) Soft outer glow
        glowPaint.setShader(new RadialGradient(
                cx, cy, orbRadius * 1.6f,
                new int[]{withAlpha(GOLD, 90), withAlpha(ORANGE, 40), Color.TRANSPARENT},
                new float[]{0f, 0.5f, 1f},
                Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, orbRadius * 1.6f, glowPaint);

        // 2) Rotating wireframe sphere — a few tilted ellipses standing in
        // for latitude/longitude lines on a rotating globe.
        for (int i = 0; i < 3; i++) {
            canvas.save();
            canvas.translate(cx, cy);
            canvas.rotate(rotation * (i % 2 == 0 ? 1 : -1) * 0.6f + i * 60);
            canvas.scale(1f, 0.35f + i * 0.25f);
            canvas.drawCircle(0, 0, orbRadius, wireframePaint);
            canvas.restore();
        }

        // 3) Radiating rays, slowly rotating, each pulsing in length
        for (int i = 0; i < NUM_RAYS; i++) {
            double angle = Math.toRadians((360.0 / NUM_RAYS) * i + rotation * 0.8);
            double pulse = 0.7 + 0.3 * Math.sin(t * Math.PI * 2 * 2 + i);
            float len = (float) (orbRadius * (1.15 + 0.35 * pulse));
            float x = cx + (float) (Math.cos(angle) * len);
            float y = cy + (float) (Math.sin(angle) * len);
            rayPaint.setColor(i % 2 == 0 ? GOLD : ORANGE);
            rayPaint.setAlpha((int) (140 * pulse));
            canvas.drawLine(cx, cy, x, y, rayPaint);
        }

        // 4) Sweeping arc, circling the orb
        float sweepStart = (rotation * 1.5f) % 360f;
        canvas.drawArc(cx - orbRadius, cy - orbRadius, cx + orbRadius, cy + orbRadius,
                sweepStart, 70f, false, arcPaint);

        // 5) Orbiting sparkle particles
        for (int i = 0; i < NUM_PARTICLES; i++) {
            double angle = Math.toRadians(particleAngleOffset[i] + rotation * particleSpeed[i]);
            float r = orbRadius * particleRadiusFrac[i];
            float x = cx + (float) (Math.cos(angle) * r);
            float y = cy + (float) (Math.sin(angle) * r);
            float twinkle = (float) (0.5 + 0.5 * Math.sin(t * Math.PI * 2 * 3 + i));
            particlePaint.setAlpha((int) (180 * twinkle) + 40);
            canvas.drawCircle(x, y, particleSize[i], particlePaint);
        }

        // 6) Pulsing bright core
        float corePulse = (float) (0.8 + 0.2 * Math.sin(t * Math.PI * 2 * 2));
        corePaint.setShader(new RadialGradient(
                cx, cy, orbRadius * 0.55f * corePulse,
                new int[]{Color.WHITE, GOLD, Color.TRANSPARENT},
                new float[]{0f, 0.4f, 1f},
                Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, orbRadius * 0.55f * corePulse, corePaint);
    }

    private static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }
}
