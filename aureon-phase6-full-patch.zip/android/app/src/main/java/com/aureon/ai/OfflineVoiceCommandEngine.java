package com.aureon.ai;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.Settings;

import androidx.core.content.ContextCompat;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Offline command router for device navigation and accessibility automation. */
public final class OfflineVoiceCommandEngine {
    public interface Result { void onHandled(String message); }
    private OfflineVoiceCommandEngine() {}

    // "message pavan saying I'm on my way", "whatsapp pavan: running late",
    // "text pavan I'm on my way"
    private static final Pattern CONTACT_MESSAGE_PATTERN = Pattern.compile(
            "(?i)^(?:message|whatsapp|text)\\s+([a-zA-Z ]+?)\\s*(?:saying|that says|:)\\s+(.+)$");

    public static boolean handle(Context context, String raw, Result result) {
        if (raw == null) return false;
        String text = raw.trim();
        String lower = text.toLowerCase(Locale.ROOT);
        if (lower.isEmpty()) return false;
        try {
            if (lower.equals("read screen") || lower.equals("read the screen") || lower.equals("what is on screen") || lower.equals("screen read")) {
                if (!AureonAccessibilityService.isEnabled()) { result.onHandled("Enable Aureon's Accessibility permission to read the screen."); return true; }
                String screen = AureonAccessibilityService.readScreen();
                result.onHandled(screen.isEmpty() ? "I can't read any visible text on this screen." : screen);
                return true;
            }

            // ---- Message/WhatsApp a contact by name (checked before the
            // generic "type what's on screen" handler below) ----
            Matcher contactMatch = CONTACT_MESSAGE_PATTERN.matcher(text);
            if (contactMatch.matches()) {
                String name = contactMatch.group(1).trim();
                String message = contactMatch.group(2).trim();
                if (messageContact(context, name, message, result)) return true;
                // Contact not found — fall through to normal handling below.
            }

            if (lower.startsWith("type ") || lower.startsWith("write ") || lower.startsWith("message ") || lower.startsWith("send message ")) {
                String payload = text.replaceFirst("(?i)^(type|write|message|send message)\\s+", "").trim();
                boolean ok = AureonAccessibilityService.typeText(payload);
                result.onHandled(ok ? "Typed it." : "Enable Aureon's Accessibility permission and focus a text box first.");
                return true;
            }
            if (lower.startsWith("append ")) {
                boolean ok = AureonAccessibilityService.appendText(text.substring(7).trim());
                result.onHandled(ok ? "Added it." : "Enable Accessibility and focus a text box first.");
                return true;
            }
            if (lower.startsWith("click ") || lower.startsWith("tap ") || lower.startsWith("press ")) {
                String target = text.replaceFirst("(?i)^(click|tap|press)\\s+", "").trim();
                boolean ok = AureonAccessibilityService.clickText(target);
                result.onHandled(ok ? "Done." : "I couldn't find that control on the screen.");
                return true;
            }
            if (lower.equals("scroll down") || lower.equals("scroll")) {
                result.onHandled(AureonAccessibilityService.scroll(true) ? "Scrolled down." : "I couldn't scroll this screen."); return true;
            }
            if (lower.equals("scroll up")) {
                result.onHandled(AureonAccessibilityService.scroll(false) ? "Scrolled up." : "I couldn't scroll this screen."); return true;
            }
            if (lower.equals("go back") || lower.equals("back")) { result.onHandled(AureonAccessibilityService.globalAction(1) ? "Going back." : "Back isn't available."); return true; }
            if (lower.equals("go home") || lower.equals("home")) { result.onHandled(AureonAccessibilityService.globalAction(2) ? "Going home." : "Home isn't available."); return true; }
            if (lower.equals("recent apps") || lower.equals("open recents")) { result.onHandled(AureonAccessibilityService.globalAction(3) ? "Opening recent apps." : "Recents isn't available."); return true; }
            if (lower.equals("notifications") || lower.equals("open notifications")) { result.onHandled(AureonAccessibilityService.globalAction(4) ? "Opening notifications." : "Notifications aren't available."); return true; }
            if (lower.equals("quick settings") || lower.equals("open quick settings")) { result.onHandled(AureonAccessibilityService.globalAction(5) ? "Opening quick settings." : "Quick settings isn't available."); return true; }

            if (lower.contains("open youtube") || lower.equals("youtube")) return launchPackage(context, "com.google.android.youtube", "YouTube", result);
            if (lower.contains("open whatsapp") || lower.equals("whatsapp")) return launchPackage(context, "com.whatsapp", "WhatsApp", result);
            if (lower.contains("open camera") || lower.equals("camera")) {
                Intent i = new Intent("android.media.action.IMAGE_CAPTURE"); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i); result.onHandled("Opening camera."); return true;
            }
            if (lower.contains("open settings") || lower.equals("settings")) return start(context, Settings.ACTION_SETTINGS, "Opening settings.", result);
            if (lower.contains("wifi settings") || lower.contains("open wifi")) return start(context, Settings.ACTION_WIFI_SETTINGS, "Opening Wi-Fi settings.", result);
            if (lower.contains("bluetooth settings") || lower.contains("open bluetooth")) return start(context, Settings.ACTION_BLUETOOTH_SETTINGS, "Opening Bluetooth settings.", result);
            if (lower.contains("open accessibility") || lower.contains("accessibility settings")) return start(context, Settings.ACTION_ACCESSIBILITY_SETTINGS, "Opening Accessibility settings.", result);
            if (lower.contains("open app settings") || lower.contains("aureon settings")) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i); result.onHandled("Opening Aureon settings."); return true;
            }

            // ---- Generic "open <any installed app>" fallback ----
            // Runs after the quick-match cases above so common apps stay fast.
            if (lower.startsWith("open ")) {
                String appName = text.substring(5).trim();
                if (!appName.isEmpty() && openAnyApp(context, appName, result)) return true;
                // Not found among installed apps — fall through so the AI
                // backend can respond (e.g. "open a good book recommendation").
            }
        } catch (Exception e) { result.onHandled("I couldn't perform that action on this phone."); return true; }
        return false;
    }

    private static boolean start(Context c, String action, String message, Result result) {
        Intent i = new Intent(action); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); result.onHandled(message); return true;
    }
    private static boolean launchPackage(Context c, String pkg, String label, Result result) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) { result.onHandled(label + " isn't installed."); return true; }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i); result.onHandled("Opening " + label + "."); return true;
    }

    /**
     * Searches installed launchable apps for one whose visible name best
     * matches the spoken name (e.g. "instagram" -> "Instagram"). Picks the
     * shortest matching label so "maps" prefers "Maps" over
     * "Maps - navigation and transit" if both were ever installed.
     */
    private static boolean openAnyApp(Context context, String spokenName, Result result) {
        String needle = spokenName.toLowerCase(Locale.ROOT).trim();
        PackageManager pm = context.getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);

        String bestPackage = null;
        String bestLabel = null;
        for (ResolveInfo info : apps) {
            String label = info.loadLabel(pm).toString();
            String labelLower = label.toLowerCase(Locale.ROOT);
            if (labelLower.equals(needle) || labelLower.contains(needle)) {
                if (bestLabel == null || label.length() < bestLabel.length()) {
                    bestLabel = label;
                    bestPackage = info.activityInfo.packageName;
                }
            }
        }

        if (bestPackage == null) {
            result.onHandled("Couldn't find an app matching \"" + spokenName + "\" on this phone.");
            return false;
        }

        Intent launch = pm.getLaunchIntentForPackage(bestPackage);
        if (launch == null) {
            result.onHandled("Couldn't launch " + bestLabel + ".");
            return true;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launch);
        result.onHandled("Opening " + bestLabel + ".");
        return true;
    }

    /**
     * Looks up a contact by name and opens WhatsApp (falling back to SMS)
     * with the message pre-filled, ready to send. Returns false (instead of
     * calling result.onHandled) when the contact isn't found, so the caller
     * can fall back to older behaviour.
     */
    private static boolean messageContact(Context context, String name, String message, Result result) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            result.onHandled("Enable Aureon's Contacts permission in phone Settings to message people by name.");
            return true;
        }

        String phoneNumber = findContactNumber(context, name);
        if (phoneNumber == null) {
            return false; // let the caller fall back
        }

        String digitsOnly = phoneNumber.replaceAll("[^0-9]", "");
        // Best-effort: assume a 10-digit local number is Indian and prefix
        // the country code, since WhatsApp's deep link needs one.
        if (digitsOnly.length() == 10) {
            digitsOnly = "91" + digitsOnly;
        }

        boolean whatsappInstalled = isPackageInstalled(context, "com.whatsapp");
        try {
            if (whatsappInstalled) {
                String encoded = URLEncoder.encode(message, StandardCharsets.UTF_8.toString());
                Intent i = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://api.whatsapp.com/send?phone=" + digitsOnly + "&text=" + encoded));
                i.setPackage("com.whatsapp");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                result.onHandled("Opening WhatsApp with your message to " + name + " — tap send to deliver it.");
            } else {
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phoneNumber));
                i.putExtra("sms_body", message);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
                result.onHandled("Opening a text message to " + name + " — tap send to deliver it.");
            }
        } catch (Exception e) {
            result.onHandled("Couldn't open messaging for " + name + ".");
        }
        return true;
    }

    private static String findContactNumber(Context context, String name) {
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ ContactsContract.CommonDataKinds.Phone.NUMBER,
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME },
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    new String[]{ "%" + name + "%" },
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                return idx >= 0 ? cursor.getString(idx) : null;
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return null;
    }

    private static boolean isPackageInstalled(Context context, String pkg) {
        try {
            context.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
