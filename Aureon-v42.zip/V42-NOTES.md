# v42 — Auto test & fix (owner)
- Settings > "Auto test & fix (owner)": Auto (default) / Manual.
- Auto: jab Coding/Code mode ka jawab apne tests ke saath aaye (JS ya Python), tests khud sandbox me chal jaate hain; fail ho to AI fix karke dobara chalata hai (max 3 round). Pass hone par sudhaara hua jawab chat me naye message ke roop me aata hai. Summary chip me live steps dikhte hain.
- Bina tests wale jawab khud nahi chalte (Run button se chalte hain). Non-owner par kuch nahi hota (chup-chaap band).
- Ava Studio: pehle se har module ke tests node --permission me chalti hai aur 3 baar repair karti hai; ab uske test pass/fail aur finished projects brain me neuron bante hain.
- Ye v41 ke upar hai (v41 pehle lagao).
