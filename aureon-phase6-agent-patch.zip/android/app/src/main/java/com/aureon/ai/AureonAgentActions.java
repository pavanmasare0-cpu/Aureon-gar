package com.aureon.ai;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.provider.AlarmClock;
import android.provider.MediaStore;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Locale;

/**
 * Phase 6 — Agent: plain Android implementations of the NON-sensitive tools
 * (get_battery, open_app, set_alarm, search_web, open_url, play_music),
 * shared by the system voice assistant (AureonVoiceInteractionSession).
 *
 * make_call and send_sms are deliberately NOT here. Voice never
 * auto-executes those — a misheard word placing a real call or sending a
 * real text is too risky with no visual confirmation. Voice tells the user
 * to confirm those two in the chat screen instead, where
 * AureonActionsPlugin.java (the Capacitor-side twin of this class) handles
 * them with an on-screen confirm dialog first.
 */
public class AureonAgentActions {

    public static class ActionException extends Exception {
        public ActionException(String message) { super(message); }
    }

    public static JSONObject getBattery(Context ctx) throws JSONException {
        BatteryManager bm = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
        int level = bm != null ? bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) : -1;

        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = ctx.registerReceiver(null, filter);
        int status = batteryStatus != null ? batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1) : -1;
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;

        JSONObject ret = new JSONObject();
        ret.put("level", level);
        ret.put("charging", charging);
        return ret;
    }

    public static JSONObject openApp(Context ctx, String appName) throws ActionException, JSONException {
        if (appName == null || appName.trim().isEmpty()) throw new ActionException("app_name is required");

        PackageManager pm = ctx.getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        String needle = appName.trim().toLowerCase(Locale.US);

        ApplicationInfo bestMatch = null;
        for (ApplicationInfo appInfo : apps) {
            String label = pm.getApplicationLabel(appInfo).toString();
            String labelLower = label.toLowerCase(Locale.US);
            if (labelLower.equals(needle)) { bestMatch = appInfo; break; }
            if (bestMatch == null && labelLower.contains(needle)) bestMatch = appInfo;
        }
        if (bestMatch == null) throw new ActionException("Could not find an app matching \"" + appName + "\"");

        Intent launchIntent = pm.getLaunchIntentForPackage(bestMatch.packageName);
        if (launchIntent == null) throw new ActionException("Found \"" + appName + "\" but it can't be launched directly");
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(launchIntent);

        JSONObject ret = new JSONObject();
        ret.put("opened", pm.getApplicationLabel(bestMatch).toString());
        return ret;
    }

    public static JSONObject setAlarm(Context ctx, int hour, int minute, String label) throws ActionException, JSONException {
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
        intent.putExtra(AlarmClock.EXTRA_HOUR, hour);
        intent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
        intent.putExtra(AlarmClock.EXTRA_MESSAGE, label != null ? label : "Aureon Alarm");
        intent.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (intent.resolveActivity(ctx.getPackageManager()) == null) {
            throw new ActionException("No clock app found to set the alarm");
        }
        ctx.startActivity(intent);

        JSONObject ret = new JSONObject();
        ret.put("alarmSet", String.format(Locale.US, "%02d:%02d", hour, minute));
        return ret;
    }

    public static JSONObject searchWeb(Context ctx, String query) throws ActionException, JSONException {
        if (query == null || query.trim().isEmpty()) throw new ActionException("query is required");
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(intent);

        JSONObject ret = new JSONObject();
        ret.put("searched", query);
        return ret;
    }

    public static JSONObject openUrl(Context ctx, String url) throws ActionException, JSONException {
        if (url == null || url.trim().isEmpty()) throw new ActionException("url is required");
        String fixed = (!url.startsWith("http://") && !url.startsWith("https://")) ? "https://" + url : url;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(fixed));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(intent);

        JSONObject ret = new JSONObject();
        ret.put("opened", fixed);
        return ret;
    }

    public static JSONObject playMusic(Context ctx, String query) throws ActionException, JSONException {
        if (query == null || query.trim().isEmpty()) throw new ActionException("query is required");

        try {
            Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
            intent.putExtra(SearchManager.QUERY, query);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (intent.resolveActivity(ctx.getPackageManager()) != null) {
                ctx.startActivity(intent);
                JSONObject ret = new JSONObject();
                ret.put("playing", query);
                return ret;
            }
        } catch (Exception ignored) {
            // fall through to the browser fallback below
        }

        Intent fallback = new Intent(Intent.ACTION_VIEW);
        fallback.setData(Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
        fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(fallback);

        JSONObject ret = new JSONObject();
        ret.put("playing", query);
        ret.put("via", "youtube");
        return ret;
    }
}
