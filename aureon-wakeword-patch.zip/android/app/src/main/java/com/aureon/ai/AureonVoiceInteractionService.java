package com.aureon.ai;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.voice.VoiceInteractionService;
import android.service.voice.VoiceInteractionSession;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

/**
 * System-level entry point. Android starts this once Aureon AI is set as the
 * phone's Default Digital Assistant.
 *
 * Continuously listens in short bursts using Android's built-in
 * SpeechRecognizer, checking each result for the word "aureon". When heard,
 * it launches the overlay session (AureonVoiceInteractionSession).
 *
 * Note: this is a free, no-signup approach (Android's SpeechRecognizer)
 * rather than a dedicated wake-word engine like Porcupine. It re-listens in
 * short bursts rather than truly continuously, and Android may kill/restrict
 * this background service over time (Doze mode, battery optimization) unless
 * the app is whitelisted from battery optimization by the user.
 */
public class AureonVoiceInteractionService extends VoiceInteractionService {

    private static final String TAG = "AureonVoiceService";
    private static final String WAKE_WORD = "aureon";
    private static final long RESTART_DELAY_MS = 800;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer wakeWordRecognizer;
    private boolean listeningEnabled = false;

    @Override
    public void onReady() {
        super.onReady();
        Log.d(TAG, "Aureon voice interaction service ready.");
        listeningEnabled = true;
        startWakeWordListening();
    }

    @Override
    public void onShutdown() {
        super.onShutdown();
        Log.d(TAG, "Aureon voice interaction service shutting down.");
        listeningEnabled = false;
        stopWakeWordListening();
    }

    private void startWakeWordListening() {
        if (!listeningEnabled) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "Speech recognition not available on this device.");
            return;
        }

        stopWakeWordListening();

        wakeWordRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        wakeWordRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {}

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float rmsdB) {}

            @Override
            public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {}

            @Override
            public void onError(int error) {
                // Common/expected: no match, speech timeout. Just restart listening.
                scheduleRestart();
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION);
                boolean heardWakeWord = false;
                if (matches != null) {
                    for (String phrase : matches) {
                        if (phrase != null &&
                                phrase.toLowerCase(Locale.getDefault()).contains(WAKE_WORD)) {
                            heardWakeWord = true;
                            break;
                        }
                    }
                }

                if (heardWakeWord) {
                    Log.d(TAG, "Wake word detected — launching Aureon overlay.");
                    // Pause wake-word listening while the session is open so
                    // the two mic sessions don't fight each other.
                    stopWakeWordListening();
                    showSession(new Bundle(), VoiceInteractionSession.SHOW_WITH_ASSIST);
                    // Resume listening for the wake word again after a delay
                    // (best-effort — there's no direct session-closed callback here).
                    handler.postDelayed(() -> {
                        listeningEnabled = true;
                        startWakeWordListening();
                    }, 8000);
                } else {
                    scheduleRestart();
                }
            }

            @Override
            public void onPartialResults(Bundle partialResults) {}

            @Override
            public void onEvent(int eventType, Bundle params) {}
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);

        try {
            wakeWordRecognizer.startListening(intent);
        } catch (Exception e) {
            Log.e(TAG, "Failed to start wake-word listening", e);
            scheduleRestart();
        }
    }

    private void scheduleRestart() {
        if (!listeningEnabled) return;
        handler.postDelayed(this::startWakeWordListening, RESTART_DELAY_MS);
    }

    private void stopWakeWordListening() {
        if (wakeWordRecognizer != null) {
            try {
                wakeWordRecognizer.cancel();
                wakeWordRecognizer.destroy();
            } catch (Exception ignored) {}
            wakeWordRecognizer = null;
        }
    }
}
