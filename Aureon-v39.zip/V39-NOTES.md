# v39 — APK build ko rokne ka option + chhota wait
- Pehle: "Roko" button sirf Ava Studio ke build ke liye dikhta tha. APK Studio build (jaise "New app") ke liye koi stop nahi tha.
- Ab: APK build jab AI likh raha / quota ke wait me ho (status generating) to "Roko" button dikhta hai aur use rok deta hai (POST /api/apk/cancel). GitHub Actions ko bheji ja chuki build nahi rukti.
- Quota wait: pehle 1,2,4,8,15,15 min (6 try). Ab 15s, 30s, 1m, 2m, 4m, 5m... (10 try), wajah bhi dikhti hai. Env: AVA_APK_WAIT_MS (default 15000), AVA_APK_WAIT_MAX_MS (default 300000).
- ava-desk.html me v37 ka language header bhi included hai.
