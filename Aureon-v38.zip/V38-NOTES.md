# v38 — limits badi (defaults code me, env zaroori nahi)
Skills (backend/skills.js):
- SKILL.md file: 5 MB tak (env AUREON_SKILL_MAX_KB, default 5120)
- Ek skill prompt me: 100000 akshar tak (env AUREON_SKILL_CONTEXT_CHARS)
- Repo zip: 80 MB tak (env AUREON_SKILL_MAX_ZIP_MB), 20000 files tak (env AUREON_SKILL_MAX_FILES)
- Skills per user: 100000, per repo: 1000
- Ek message me jodi jaane wali skills: 3 (env AUREON_SKILLS_PER_PROMPT)
Coding review (backend/code-check.js):
- Review rounds default 3 (env AUREON_CODE_REVIEW_ROUNDS; 0 = band). NO_BUGS aate hi ruk jata hai.
Env variables sirf tab Render > Environment me daalo jab default badalna ho.
