# v40 — sandbox me code + tests saath chalte hain, skills ka fast delete
Sandbox run (Summary > Run in sandbox):
- Pehle sirf pehla JS block chalta tha aur 'vitest' na milne se fail hota tha.
- Ab chat ke saare JS blocks (code + tests) ek saath chalte hain: implementation -> impl, tests -> test, tests ke relative imports impl par mod jaate hain.
- vitest / @jest/globals / jest globals (describe, it, expect, vi.fn ...) sandbox me shim se chalte hain; node:test aur node:assert bhi chalte hain.
- Koi aur npm package (chai, mocha, lodash ...) ho to saaf message milta hai ki sandbox me nahi hai.
- Coding prompt me rule: tests sirf node:test/assert (ya describe/it/expect) me likho, pehle implementation block, phir tests block.
- /api/code/run ab blocks[] leta hai (max 8 blocks, 60000 chars); purana code= bhi chalta hai.
Skills (Settings > Code mode):
- Search, filters (Non-English, Bina description, source), Select mode (row tap), "Sab chuno", "Hatao (N)", "Poora source hatao".
- Ek X dabane par row turant hat jaati hai (optimistic).
- Backend: POST /api/skills/bulk-delete {names:[...]} ya {source:"https://github.com/owner/repo"}.
Deploy: backend => Render redeploy. www/ badla => APK rebuild.
