# v41 (cumulative since FINAL: v40 + v41)
1. Fix & re-run: Summary me test fail ho to "Fix & re-run (max 3 rounds)" button. Har round: asli error AI ko -> AI code sudhaarta hai -> sandbox me dobara chalta hai. Pass ho to sudhaara hua jawab chat me naye message ke roop me aata hai. (POST /api/code/fix-run, ek round per request)
2. Lessons: review ("Fixed: ...") ya fix-run se jo bug pakda jaye wo lesson ban ke save hota hai (Firestore users/{uid}/lessons). Coding aur Code mode ke prompt me sirf relevant lessons jaate hain. API: GET/POST/DELETE /api/lessons.
3. Skills index: Code mode me ab sirf relevant skills ki list (default 15, env AUREON_SKILL_INDEX_MAX) + "+N more". Pehle saari skills har message me jaati thi.
4. Python: Summary me Python code + pytest/unittest-style tests ka Run button. pytest sandbox khud deta hai (raises, approx, fixture, parametrize, skip). File/network/process (open, os, subprocess, socket ...) ast guard se band. Guard deny-list hai, pakki deewar nahi: owner-only + Approve + clean env + time limit asli suraksha hai.
5. Brain (Ava Desk neurons): ab backend ka sab kuch neuron banta hai aur kabhi trim nahi hota (Firestore aureon_brain + true totals aureon_brain_meta/totals).
   Soch: server boot, key counts | Tark: lessons, tests pass | Yaad: skills seekhi | Dar: errors/watchdog, fail runs/videos | Drishti: photo banayi/edit | Sapne: AI video.
   Sirf owner ke events (recordFor); chat ka text kabhi nahi.
Deploy: backend => Render redeploy. www/ badla => APK rebuild.
