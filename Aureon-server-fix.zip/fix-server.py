#!/usr/bin/env python3
"""Aureon: fixes backend/server.js so Render deploys again (idempotent, in-place).

Problem: new sentinel-dashboard.js exports a router, but server.js still calls
it like a factory -> sentinelDashboardFactory(db) -> crash at boot, Render
never opens a port. This also wires in the Security module.
Usage:  python3 fix-server.py backend/server.js
"""
import sys, re
p = sys.argv[1] if len(sys.argv) > 1 else 'backend/server.js'
s = open(p, encoding='utf8').read()
orig = s
done = []

# 1) requires
s2 = re.sub(r"const sentinelDashboardFactory = require\('\./sentinel-dashboard'\);[^\n]*\n",
            "const sentinelDashboard = require('./sentinel-dashboard');\n", s)
if s2 != s: s = s2; done.append('sentinel require (factory -> router)')
if "const sentinelDashboard = require('./sentinel-dashboard');" not in s:
    sys.exit("ERROR: sentinel-dashboard require line not found")
if "require('./security')" not in s:
    s = s.replace("const sentinelDashboard = require('./sentinel-dashboard');\n",
                  "const sentinelDashboard = require('./sentinel-dashboard');\nconst security = require('./security');\n", 1)
    done.append('security require')

# 2) mounts
s2 = re.sub(r"app\.use\('/api/sentinel', sentinelDashboardFactory\(db\)\);\n",
            "app.use('/api/sentinel', sentinelDashboard);\n", s)
if s2 != s: s = s2; done.append('sentinel mount (no more factory call)')
if "app.use('/api/sentinel', sentinelDashboard);" not in s:
    sys.exit("ERROR: /api/sentinel mount line not found")
if "security.router" not in s:
    s = s.replace("app.use('/api/sentinel', sentinelDashboard);\n",
                  "app.use('/api/sentinel', sentinelDashboard);\napp.use('/api/security', security.router);\n", 1)
    done.append('security router mount')

# 3) guard (before express.json) + webhook (raw body) + bodyGuard (after json)
if "security.guard" not in s:
    m = re.search(r"const app = express\(\);\n", s)
    if not m: sys.exit("ERROR: 'const app = express();' not found")
    ins = "" if "app.set('trust proxy'" in s else \
        "// Render sits behind one proxy hop: trust exactly that, so req.ip is the real client address.\napp.set('trust proxy', 1);\n"
    s = s[:m.end()] + ins + s[m.end():]
    mj = re.search(r"app\.use\(express\.json\([^\n]*\)\);\n", s)
    if not mj: sys.exit("ERROR: app.use(express.json(...)) not found")
    s = (s[:mj.start()] + "app.use(security.guard);      // IP block-list, rate-limit, URL signatures\n"
         "// GitHub webhook needs the RAW body for signature checking, so it is mounted before express.json()\n"
         "app.post('/api/security/github-webhook', express.raw({ type: '*/*', limit: '5mb' }), security.githubWebhook);\n"
         + mj.group(0) + "app.use(security.bodyGuard);  // payload patterns (flagged by default)\n" + s[mj.end():])
    done.append('guard + webhook + bodyGuard + trust proxy')

if s == orig:
    print('server.js already fixed - nothing to do'); sys.exit(0)
open(p + '.bak-before-fix', 'w', encoding='utf8').write(orig)
open(p, 'w', encoding='utf8').write(s)
print('server.js fixed:'); [print('  -', d) for d in done]
print('backup:', p + '.bak-before-fix')
